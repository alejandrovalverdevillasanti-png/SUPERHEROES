# Superheroes: Multiverse Ultimate — mods + modpack (Forge 1.20.1)

| Mod | ID | Contenido |
|---|---|---|
| Multiverse Core | `multiverse_core` | Pestaña creativa "Multiverse Ultimate" + Cosmic Energy Cell |
| Multiverse Omnitrix | `multiverse_omnitrix` | Omnitrix (prototipo, solo objeto) |
| Multiverse Heroes | `multiverse_heroes` | Hero Emblem (objeto provisional) |

Omnitrix y Heroes requieren Core. Cada mod es un proyecto Gradle independiente en `mods/`.

## Compilar
Sube el contenido de esta carpeta a un repositorio de GitHub. La acción **Build mods and modpack**
compila los 3 mods y genera el artefacto `modpack` con:
- `Multiverse-Ultimate-0.1.0.mrpack` (Modrinth App, Prism, ATLauncher)
- `Multiverse-Ultimate-0.1.0.zip` (carpeta `mods/` para copiar a cualquier instancia Forge 1.20.1)

Local: `python3 scripts/build_modpack.py <carpeta_con_jars> dist`

## Nota
Los IDs de los objetos cambiaron respecto al proyecto original (`multiverseultimate:omnitrix` → `multiverse_omnitrix:omnitrix`).
