package com.multiverseultimate.heroes;

import com.mojang.logging.LogUtils;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

@Mod(MultiverseHeroes.MOD_ID)
public class MultiverseHeroes {
    public static final String MOD_ID = "multiverse_heroes";
    public static final Logger LOGGER = LogUtils.getLogger();
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    public static final RegistryObject<Item> HERO_EMBLEM = ITEMS.register("hero_emblem",
            () -> new Item(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public MultiverseHeroes() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(modBus);
        modBus.addListener(this::addToMultiverseTab);
        LOGGER.info("Multiverse Heroes initialized.");
    }

    // The tab is registered by multiverse_core; we only reference it by key (no compile-time dependency).
    private static final ResourceKey<CreativeModeTab> MULTIVERSE_TAB = ResourceKey.create(
            Registries.CREATIVE_MODE_TAB, new ResourceLocation("multiverse_core", "tab"));

    private void addToMultiverseTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey().equals(MULTIVERSE_TAB)) {
            event.accept(HERO_EMBLEM);
        }
    }
}
