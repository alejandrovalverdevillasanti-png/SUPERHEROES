#!/usr/bin/env python3
"""Assemble the modpack from compiled mod jars.

Usage: python scripts/build_modpack.py <dir_with_jars> [out_dir]
Produces:
  <out>/Multiverse-Ultimate-<ver>.mrpack  (Modrinth format; Prism, ATLauncher, Modrinth App)
  <out>/Multiverse-Ultimate-<ver>.zip     (simple zip: mods/ folder + instructions)
"""
import glob, json, os, shutil, sys, zipfile

src = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else "dist"
os.makedirs(out, exist_ok=True)

meta = json.load(open(os.path.join(os.path.dirname(__file__), "..", "modpack", "pack.json")))
ver = meta["version"]
# keep only runtime jars (skip -sources / -javadoc / -dev)
jars = sorted(j for j in glob.glob(os.path.join(src, "**", "*.jar"), recursive=True)
              if not any(x in os.path.basename(j) for x in ("-sources", "-javadoc", "-dev")))
if len(jars) < 3:
    sys.exit(f"Expected at least 3 mod jars, found {len(jars)}: {jars}")
print("Mods:", *map(os.path.basename, jars), sep="\n  ")

index = {
    "formatVersion": 1, "game": "minecraft",
    "versionId": ver, "name": meta["name"], "summary": meta["summary"],
    "files": [],
    "dependencies": {"minecraft": meta["minecraft"], "forge": meta["forge"]},
}
mrpack = os.path.join(out, f"Multiverse-Ultimate-{ver}.mrpack")
with zipfile.ZipFile(mrpack, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("modrinth.index.json", json.dumps(index, indent=2))
    for j in jars:
        z.write(j, "overrides/mods/" + os.path.basename(j))

plain = os.path.join(out, f"Multiverse-Ultimate-{ver}.zip")
with zipfile.ZipFile(plain, "w", zipfile.ZIP_DEFLATED) as z:
    for j in jars:
        z.write(j, "mods/" + os.path.basename(j))
    z.writestr("LEEME.txt",
        f"{meta['name']} {ver}\nMinecraft {meta['minecraft']} + Forge {meta['forge']}\n"
        "Copia la carpeta 'mods' a la carpeta de tu instancia Forge 1.20.1.\n")
print("Created:", mrpack, plain)
